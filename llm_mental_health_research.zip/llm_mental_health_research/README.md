# LLM Mental Health Research Agent

A multi-agent AI system using CrewAI that automatically searches for and analyzes research on Large Language Model applications in mental health, delivering comprehensive reports via Telegram.

## Features

- 🤖 **Multi-Agent Architecture**: Specialized agents for research, analysis, and report writing
- 🔍 **Automated Web Search**: Uses Serper API for real-time research discovery
- 📊 **Comprehensive Analysis**: Synthesizes findings across multiple sources
- 📱 **Telegram Notifications**: Delivers formatted reports directly to Telegram
- ⏰ **Flexible Scheduling**: Run once, on intervals, or with cron expressions
- 🔧 **Production-Ready**: Robust error handling, logging, and configuration management

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Scheduler                          │
│              (APScheduler)                          │
└─────────────────┬───────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────┐
│              CrewAI System                          │
│  ┌─────────────────────────────────────────────┐   │
│  │  Researcher Agent (SerperDevTool)           │   │
│  │  ↓ Search for LLM mental health papers     │   │
│  └─────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────┐   │
│  │  Analyst Agent                              │   │
│  │  ↓ Analyze trends and effectiveness        │   │
│  └─────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────┐   │
│  │  Report Writer Agent                        │   │
│  │  ↓ Generate comprehensive report           │   │
│  └─────────────────────────────────────────────┘   │
└─────────────────┬───────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────┐
│          Telegram Notifier                          │
│     (Message chunking & formatting)                 │
└─────────────────────────────────────────────────────┘
```

## Installation

### 1. Clone and Setup

```
git clone <repository-url>
cd llm_mental_health_research
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment

Copy `.env.example` to `.env` and fill in your API keys:

```
# Get Gemini API key from https://aistudio.google.com/app/apikey
GEMINI_API_KEY=...

# Get Serper API key from https://serper.dev/
SERPER_API_KEY=...

# Configure Telegram bot (see below)
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
```

### 3. Setup Telegram Bot

1. Open Telegram and search for `@BotFather`
2. Send `/newbot` and follow instructions
3. Copy your bot token to `.env` as `TELEGRAM_BOT_TOKEN`
4. Send a message to your bot
5. Visit `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates`
6. Find your `chat_id` in the JSON response
7. Add it to `.env` as `TELEGRAM_CHAT_ID`

## Usage

### Test Telegram Connection

```
python -m src.main test
```

### Run Once

Execute research immediately and send results:

```
python -m src.main once
```

### Run on Schedule

Run continuously with configured interval:

```
python -m src.main schedule
```

Schedule configuration in `.env`:
```
SCHEDULE_INTERVAL_MINUTES=1440  # Run daily
SCHEDULE_ENABLED=true
```

### Custom Cron Schedule

Modify `src/main.py` to use cron expressions:

```
# Daily at 9 AM
scheduler.start_with_cron("0 9 * * *")

# Every 6 hours
scheduler.start_with_cron("0 */6 * * *")

# Every Monday at 9 AM
scheduler.start_with_cron("0 9 * * MON")
```

## Configuration

### Agent Customization (`config/agents.yaml`)

Modify agent roles, goals, and behavior:

```
researcher:
  role: "Your custom role"
  goal: "Your custom goal"
  max_iter: 15  # Maximum iterations
  memory: true   # Enable memory
```

### Task Customization (`config/tasks.yaml`)

Adjust research focus and output format:

```
search_research:
  description: "Your custom search criteria"
  expected_output: "Your expected format"
```

## Development

### Project Structure

```
llm_mental_health_research/
├── config/              # YAML configurations
│   ├── agents.yaml      # Agent definitions
│   └── tasks.yaml       # Task definitions
├── src/
│   ├── main.py          # Entry point
│   ├── crew.py          # CrewAI setup
│   ├── telegram_notifier.py  # Telegram integration
│   ├── scheduler.py     # Task scheduling
│   └── models.py        # Data models
├── logs/                # Log files
└── tests/               # Unit tests
```

### Running Tests

```
pytest tests/ -v
```

### Logging

Logs are written to:
- Console (stdout)
- File: `logs/research_crew.log` (rotated at 10MB, kept for 1 week)

Adjust log level in `.env`:
```
LOG_LEVEL=DEBUG  # DEBUG, INFO, WARNING, ERROR
```

## Advanced Usage

### Async Execution

```
from src.crew import MentalHealthResearchCrew

crew = MentalHealthResearchCrew()
result = await crew.execute_async()
print(result.report)
```

### Custom Search Parameters

```
from crewai_tools import SerperDevTool

search_tool = SerperDevTool(
    n_results=20,          # More results
    search_type="news",    # Focus on news
    tbs="qdr:m"            # Last month only
)
```

## Troubleshooting

### Issue: "SERPER_API_KEY not found"
**Solution**: Ensure `.env` file exists and contains your API key
```
                  ▼
┌─────────────────────────────────────────────────────┐
│              CrewAI System                          │
│  ┌─────────────────────────────────────────────┐   │
│  │  Researcher Agent (SerperDevTool)           │   │
│  │  ↓ Search for LLM mental health papers     │   │
│  └─────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────┐   │
│  │  Analyst Agent                              │   │
│  │  ↓ Analyze trends and effectiveness        │   │
│  └─────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────┐   │
│  │  Report Writer Agent                        │   │
│  │  ↓ Generate comprehensive report           │   │
│  └─────────────────────────────────────────────┘   │
└─────────────────┬───────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────┐
│          Telegram Notifier                          │
│     (Message chunking & formatting)                 │
└─────────────────────────────────────────────────────┘
```

## Installation

### 1. Clone and Setup

```
git clone <repository-url>
cd llm_mental_health_research
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment

Copy `.env.example` to `.env` and fill in your API keys:

```
# Get Gemini API key from https://aistudio.google.com/app/apikey
GEMINI_API_KEY=...

# Get Serper API key from https://serper.dev/
SERPER_API_KEY=...

# Configure Telegram bot (see below)
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
```

### 3. Setup Telegram Bot

1. Open Telegram and search for `@BotFather`
2. Send `/newbot` and follow instructions
3. Copy your bot token to `.env` as `TELEGRAM_BOT_TOKEN`
4. Send a message to your bot
5. Visit `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates`
6. Find your `chat_id` in the JSON response
7. Add it to `.env` as `TELEGRAM_CHAT_ID`

## Usage

### Test Telegram Connection

```
python -m src.main test
```

### Run Once

Execute research immediately and send results:

```
python -m src.main once
```

### Run on Schedule

Run continuously with configured interval:

```
python -m src.main schedule
```

Schedule configuration in `.env`:
```
SCHEDULE_INTERVAL_MINUTES=1440  # Run daily
SCHEDULE_ENABLED=true
```

### Custom Cron Schedule

Modify `src/main.py` to use cron expressions:

```
# Daily at 9 AM
scheduler.start_with_cron("0 9 * * *")

# Every 6 hours
scheduler.start_with_cron("0 */6 * * *")

# Every Monday at 9 AM
scheduler.start_with_cron("0 9 * * MON")
```

## Configuration

### Agent Customization (`config/agents.yaml`)

Modify agent roles, goals, and behavior:

```
researcher:
  role: "Your custom role"
  goal: "Your custom goal"
  max_iter: 15  # Maximum iterations
  memory: true   # Enable memory
```

### Task Customization (`config/tasks.yaml`)

Adjust research focus and output format:

```
search_research:
  description: "Your custom search criteria"
  expected_output: "Your expected format"
```

## Development

### Project Structure

```
llm_mental_health_research/
├── config/              # YAML configurations
│   ├── agents.yaml      # Agent definitions
│   └── tasks.yaml       # Task definitions
├── src/
│   ├── main.py          # Entry point
│   ├── crew.py          # CrewAI setup
│   ├── telegram_notifier.py  # Telegram integration
│   ├── scheduler.py     # Task scheduling
│   └── models.py        # Data models
├── logs/                # Log files
└── tests/               # Unit tests
```

### Running Tests

```
pytest tests/ -v
```

### Logging

Logs are written to:
- Console (stdout)
- File: `logs/research_crew.log` (rotated at 10MB, kept for 1 week)

Adjust log level in `.env`:
```
LOG_LEVEL=DEBUG  # DEBUG, INFO, WARNING, ERROR
```

## Advanced Usage

### Async Execution

```
from src.crew import MentalHealthResearchCrew

crew = MentalHealthResearchCrew()
result = await crew.execute_async()
print(result.report)
```

### Custom Search Parameters

```
from crewai_tools import SerperDevTool

search_tool = SerperDevTool(
    n_results=20,          # More results
    search_type="news",    # Focus on news
    tbs="qdr:m"            # Last month only
)
```

## Cost Optimization

Estimated costs per execution:
- Gemini API (1.5 Pro): Free tier available, or pay-per-use
- Serper API: ~$0.01
- **Total: ~$0.01 per run (with free Gemini)**

Daily schedule (1440 minutes): ~$0.30/month

Tips to reduce costs:
1. Use Gemini 1.5 Flash for faster/cheaper inference
2. Reduce search results (`MAX_SEARCH_RESULTS=5`)
3. Increase schedule interval

## Troubleshooting

### Issue: "SERPER_API_KEY not found"
**Solution**: Ensure `.env` file exists and contains your API key

### Issue: Telegram messages not sending
**Solution**: 
1. Test connection: `python -m src.main test`
2. Verify bot token and chat ID
3. Check bot permissions

### Issue: "Rate limit exceeded"
**Solution**: Increase `SCHEDULE_INTERVAL_MINUTES` or implement exponential backoff

### Issue: Long execution times
**Solution**: 
- Reduce `MAX_SEARCH_RESULTS` in `.env`
- Set `RESEARCH_DEPTH=quick` for faster results
- Use `gpt-4o-mini` instead of `gpt-4o`
```
